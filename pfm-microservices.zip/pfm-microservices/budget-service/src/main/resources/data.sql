INSERT INTO budgets(id,user_id,category,limit_amount,spent_amount) VALUES
(1,'user-1','Groceries',4000,0),
(2,'user-1','Transport',2000,0);
